package com.vitthalmirji.spring;

import javafx.scene.chart.BarChart;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.knowm.xchart.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.util.StreamUtils;
import org.apache.spark.ml.feature.StringIndexer;
import org.knowm.xchart.style.Styler;
import org.apache.spark.api.java.function.FilterFunction;

import org.apache.spark.sql.RelationalGroupedDataset;
import org.springframework.web.bind.annotation.ResponseBody;


import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

import static org.apache.spark.sql.functions.col;

//@RequestMapping("spark-context")
@Controller
public class SparkController<chart> {
    @Autowired
    private SparkSession sparkSession;
    private Dataset<Row> dataframe;
    private void read_date_() {
        if (dataframe != null)
            return;
        dataframe = sparkSession.read().option("header", "true").csv("/home/eslam/Main/ITI/Java & UML/DemoSpark/src/main/resources/Wuzzuf_Jobs.csv");
    }


    @GetMapping("/read")
    public ResponseEntity<String> read() {
        read_date_();
        return ResponseEntity.ok(dataframe.toJSON().collectAsList().toString());
    }



    @GetMapping("Summary")
    public ResponseEntity<String> Summary() {
        read_date_();

        return ResponseEntity.ok(dataframe.describe().toJSON().collectAsList().toString());
    }

    @RequestMapping("showSummary")
    public ResponseEntity<String> summary() {
        read_date_();
        //2. Display structure and summary of the data.
        System.out.println("+--------------------+ \n display structure of Data \n+--------------------+");
        //dataframe.schema().treeString();
        System.out.println("+--------------------+ \n display summary of Data \n+--------------------+");

        return ResponseEntity.ok(dataframe.describe().showString(20, 100, false));
    }

    private Dataset<Row> CleanDataFrame;

    private void read_clean_date() {
        read_date_();
        dataframe.dropDuplicates();
        CleanDataFrame = dataframe.filter((FilterFunction<Row>) col -> !col.get(5).equals("null Yrs of Exp"));
    }


    @GetMapping("clean")
    public ResponseEntity<String> clean() {
        read_clean_date();

        return ResponseEntity.ok(CleanDataFrame.toJSON().collectAsList().toString());
    }

    public String Html(Dataset<Row> CleanDataFrame,HTMLTableBuilder htmlBuilder)
    {
        List<List<String>> a= new ArrayList<>();
        for(Row row:CleanDataFrame.collectAsList())
        {
            List<String> myrows = new ArrayList<>();
            for(int i=0;i<row.length();i++)
            {
                myrows.add(row.get(i).toString());
            }
            a.add(myrows);
        }
        htmlBuilder=htmlBuilder;
        for (int i =0;i <CleanDataFrame.collectAsList().size();i++){

            htmlBuilder.addRowValues(a.get(i));
        }
        String table = htmlBuilder.build();
        return table.toString();

    }


    @RequestMapping("read_clean_data1")
    public ResponseEntity<String> read_clean_data1() {
        read_clean_date();
        HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 4717, 8);
        htmlBuilder.addTableHeader("Title","Company","Location","Type","Level","YearsExp","Country","Skills");
        String out=Html(CleanDataFrame,htmlBuilder);
        return ResponseEntity.ok(out);
    }


    @GetMapping("countJson")
    public ResponseEntity<String> countJson() {
        read_clean_date();
        RelationalGroupedDataset GroupBycompany = CleanDataFrame.groupBy("Company");
        Dataset<Row> companyCount = GroupBycompany.count().orderBy(col("count").desc());
        return ResponseEntity.ok(companyCount.toJSON().collectAsList().toString());
    }

    @RequestMapping("count")
    public ResponseEntity<String> count() {

        //4. Count the jobs for each company and display that in order (What are the most demanding companies for jobs?)
        read_clean_date();
        RelationalGroupedDataset GroupBycompany = CleanDataFrame.groupBy("Company");
        Dataset<Row> companyCount = GroupBycompany.count().orderBy(col("count").desc());
        companyCount.limit(10).show();
        System.out.println("the most demanding companies for jobs is : ");

        HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 4717, 8);
        htmlBuilder.addTableHeader("Company","Count");
        return ResponseEntity.ok(Html(companyCount.limit(10),htmlBuilder));
    }


    @GetMapping("countTitleJson")
    public ResponseEntity<String> countTitleJson() {
        read_clean_date();
        RelationalGroupedDataset GroupBytitles = CleanDataFrame.groupBy("Title");
        Dataset<Row> TitleCount = GroupBytitles.count().orderBy(col("count").desc());
        return ResponseEntity.ok(TitleCount.toJSON().collectAsList().toString());
    }

    @RequestMapping("popular_job_titles")
    public ResponseEntity<String> popular_job_titles() {
        read_clean_date();
        RelationalGroupedDataset GroupBytitles = CleanDataFrame.groupBy("Title");
        Dataset<Row> TitleCount = GroupBytitles.count().orderBy(col("count").desc());
        System.out.println("+--------------------+ \nCount the jobs for each Title \n+--------------------+");
        TitleCount.limit(10).toJSON().show();
        System.out.println("the most demanding Title for jobs is : ");
        //TitleCount.limit(1).show();
        HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 4717, 8);
        htmlBuilder.addTableHeader("Title","Count");
        return ResponseEntity.ok(Html(TitleCount.limit(10),htmlBuilder));
    }


    @GetMapping("popular_areas_json")
    public ResponseEntity<String> popular_areas_json() {
        read_clean_date();
        RelationalGroupedDataset GroupByArea = CleanDataFrame.groupBy("Location");
        Dataset<Row> AreaCount = GroupByArea.count().orderBy(col("count").desc());
        return ResponseEntity.ok(AreaCount.toJSON().collectAsList().toString());
    }


    @RequestMapping("popular_areas")
    //8. Find out the most popular areas?
    public ResponseEntity<String> popular_areas() {
        read_clean_date();
        RelationalGroupedDataset GroupByArea = CleanDataFrame.groupBy("Location");
        Dataset<Row> AreaCount = GroupByArea.count().orderBy(col("count").desc());
        //System.out.println("\nCount the jobs for each Location \n");
        AreaCount.limit(10).toJSON().show();
        ;
        System.out.println("the most demanding Location for jobs is : ");
        HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 4717, 8);
        htmlBuilder.addTableHeader("AreaName","Count");
        return ResponseEntity.ok(Html(AreaCount.limit(10),htmlBuilder));
    }


    @GetMapping("most_important_skills_required_json")
    public ResponseEntity<String> most_important_skills_required_json() {
        read_clean_date();
        RelationalGroupedDataset GroupByData = CleanDataFrame.groupBy("Skills");
        Dataset<Row> SkillsCount = GroupByData.count().orderBy(col("count").desc());
        return ResponseEntity.ok(SkillsCount.toJSON().collectAsList().toString());
    }


    @RequestMapping("most_important_skills_required")
    //10. Print skills one by one and how many each repeated and order the output to find out the most important skills required?
    public ResponseEntity<String> most_important_skills_required() {
        read_clean_date();
        RelationalGroupedDataset GroupByData = CleanDataFrame.groupBy("Skills");
        Dataset<Row> SkillsCount = GroupByData.count().orderBy(col("count").desc());
        System.out.println("+--------------------+ \nCount the jobs for each Skill \n+--------------------+");
        SkillsCount.limit(10).show();
        System.out.println("the most important skills required is : ");
        HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 4717, 8);
        htmlBuilder.addTableHeader("Skills","Count");
        return ResponseEntity.ok(Html(SkillsCount.limit(10),htmlBuilder));
    }

    @GetMapping("YearsExp_feature_json")
    public ResponseEntity<String> YearsExp_feature_json() {
        read_clean_date();
        StringIndexer indexer = new StringIndexer();
        indexer.setInputCol("YearsExp").setOutputCol("Years_ind");
        Dataset<Row> Years_ind = (Dataset<Row>) indexer.fit(CleanDataFrame).transform(CleanDataFrame);
        return ResponseEntity.ok(Years_ind.select("YearsExp", "Years_ind").toJSON().collectAsList().toString());
    }

    @RequestMapping("YearsExp_feature")
    //11. Factorize the YearsExp feature and convert it to numbers in new col. (Bounce )s
    public ResponseEntity<String> YearsExp_feature() {
        read_clean_date();
        org.apache.spark.ml.feature.StringIndexer indexer = new org.apache.spark.ml.feature.StringIndexer();
        indexer.setInputCol("YearsExp").setOutputCol("Years_ind");
        Dataset<Row> Years_ind = (Dataset<Row>) indexer.fit(CleanDataFrame).transform(CleanDataFrame);
        System.out.println("Factorize the YearsExp feature and convert it to numbers in new col");
        HTMLTableBuilder htmlBuilder = new HTMLTableBuilder(null, true, 4717, 8);
        htmlBuilder.addTableHeader("Title","Company","Location","Type","Level","YearsExp","Country","Skills","Num-Of-Features");
        return ResponseEntity.ok(Html(Years_ind.limit(10),htmlBuilder));

    }

    //@RequestMapping("chart1")
    //5. Show step 4 in a pie chart
    @GetMapping(
            value = "/chart1",
            produces = MediaType.IMAGE_JPEG_VALUE
    )
    public @ResponseBody
    byte[]  chart1() throws IOException {
        read_clean_date();
        Chart pie = new Chart();
        RelationalGroupedDataset GroupBycompany = CleanDataFrame.groupBy("Company");
        Dataset<Row> companyCount = GroupBycompany.count().orderBy(col("count").desc());
        PieChart chart = pie.getPieChartforCompany(companyCount, 10);
        //JFrame imgg = new SwingWrapper<>(chart).displayChart();
        BitmapEncoder.saveBitmap(chart,"F:\\ITI Pro\\JAVA\\Final\\DemoSpark\\src\\main\\resources\\1", BitmapEncoder.BitmapFormat.JPG);
        BufferedImage imgg = ImageIO.read(new File("F:\\ITI Pro\\JAVA\\Final\\DemoSpark\\src\\main\\resources\\1.jpg"));
//        BufferedImage bi = getScreenShot(imgg);
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        ImageIO.write(imgg, "jpeg", os);
        InputStream is = new ByteArrayInputStream(os.toByteArray());

        return IOUtils.toByteArray(is);
    }
    @GetMapping(
            value = "/chart2",
            produces = MediaType.IMAGE_JPEG_VALUE
    )
    public @ResponseBody
    byte[]  chart2() throws IOException {
        read_clean_date();
        RelationalGroupedDataset GroupBytitles = CleanDataFrame.groupBy("Title");
        Dataset<Row> TitleCount = GroupBytitles.count().orderBy(col("count").desc());
        Chart bar=new Chart();
        CategoryChart BarChart = bar.getBarChartforTitles(TitleCount , 10);
        BitmapEncoder.saveBitmap(BarChart,"F:\\ITI Pro\\JAVA\\Final\\DemoSpark\\src\\main\\resources\\2", BitmapEncoder.BitmapFormat.JPG);
        BufferedImage imgg = ImageIO.read(new File("F:\\ITI Pro\\JAVA\\Final\\DemoSpark\\src\\main\\resources\\2.jpg"));
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        ImageIO.write(imgg, "jpeg", os);
        InputStream is = new ByteArrayInputStream(os.toByteArray());

        return IOUtils.toByteArray(is);
    }
    @GetMapping(
            value = "/chart3",
            produces = MediaType.IMAGE_JPEG_VALUE
    )
    public @ResponseBody
    byte[]  chart3() throws IOException {
        read_clean_date();
        RelationalGroupedDataset GroupByArea = CleanDataFrame.groupBy("Location");
        Dataset<Row> AreaCount = GroupByArea.count().orderBy(col("count").desc());
        Chart barforArea=new Chart();
        CategoryChart BarChartforArea = barforArea.getBarChartforLocations(AreaCount , 10);
        BitmapEncoder.saveBitmap(BarChartforArea,"F:\\ITI Pro\\JAVA\\Final\\DemoSpark\\src\\main\\resources\\3", BitmapEncoder.BitmapFormat.JPG);
        BufferedImage imgg = ImageIO.read(new File("F:\\ITI Pro\\JAVA\\Final\\DemoSpark\\src\\main\\resources\\3.jpg"));
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        ImageIO.write(imgg, "jpeg", os);
        InputStream is = new ByteArrayInputStream(os.toByteArray());

        return IOUtils.toByteArray(is);
    }



}
