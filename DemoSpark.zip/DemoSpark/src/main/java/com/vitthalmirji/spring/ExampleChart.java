package com.vitthalmirji.spring;

import org.knowm.xchart.internal.chartpart.Chart;

import java.util.List;

public interface ExampleChart<C extends Chart<?, ?>> {

  C getChart(String x,String y,String title,List<String> list1,List<Double> list2,int limit);

  //String getExampleChartName();
}
