package com.vitthalmirji.spring;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.CategoryChartBuilder;
import org.knowm.xchart.PieChart;
import org.knowm.xchart.PieChartBuilder;
import org.knowm.xchart.style.Styler;

import java.util.ArrayList;
import java.util.List;


public class Chart implements ExampleChart<CategoryChart> {



    @Override
    public CategoryChart getChart(String x,String y,String title,List<String> list1,List<Double> list2,int limit) {

        // Create Chart
        CategoryChart chart =
                new CategoryChartBuilder()
                        .width(800)
                        .height(600)
                        .title(title)
                        .xAxisTitle(x)
                        .yAxisTitle(y)
                        .build();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);

        chart.getStyler().setPlotGridLinesVisible(false);

        // Series
        chart.addSeries(x, list1.subList(0,limit), list2.subList(0,limit));

        return chart;
    }

    public CategoryChart getBarChartforTitles( Dataset<Row> TitleCount ,int limit) {

        // Create Chart
        CategoryChart chart =
                new CategoryChartBuilder()
                        .width(800)
                        .height(600)
                        .title("Bar Chart for Titles")
                        .xAxisTitle("Titles")
                        .yAxisTitle("Count")
                        .build();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
        chart.getStyler().setPlotGridLinesVisible(false);


        Dataset<Row> Titles = TitleCount.select("Title");
        List<String> TitlesList = new ArrayList<>();
        TitlesList   = Titles.as(Encoders.STRING()).collectAsList();

        Dataset<Row> count = TitleCount.select("count");
        List<String> CountList = new ArrayList<>();
        CountList   = count.as(Encoders.STRING()).collectAsList();

        List<Integer> CountList1 = new ArrayList<>();
        for (String p:CountList) {
            CountList1.add(Integer.parseInt(p));
        }
        // Series
        chart.addSeries("Count the jobs for each Title", TitlesList.subList(0,limit),CountList1.subList(0,limit));

        return chart;
    }

    public CategoryChart getBarChartforLocations( Dataset<Row> AreaCount ,int limit) {

        // Create Chart
        CategoryChart chart =
                new CategoryChartBuilder()
                        .width(800)
                        .height(600)
                        .title("Bar Chart for Locations")
                        .xAxisTitle("Location")
                        .yAxisTitle("Count")
                        .build();

        // Customize Chart
        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNW);
        chart.getStyler().setPlotGridLinesVisible(false);


        Dataset<Row> Area = AreaCount.select("Location");
        List<String> AreasList = new ArrayList<>();
        AreasList   = Area.as(Encoders.STRING()).collectAsList();

        Dataset<Row> count = AreaCount.select("count");
        List<String> CountList = new ArrayList<>();
        CountList   = count.as(Encoders.STRING()).collectAsList();

        List<Integer> CountList1 = new ArrayList<>();
        for (String p:CountList) {
            CountList1.add(Integer.parseInt(p));
        }
        // Series
        chart.addSeries("Count the jobs for each Area", AreasList.subList(0,limit),CountList1.subList(0,limit));

        return chart;
    }

    public static PieChart getPieChartforCompany( Dataset<Row> companyCount , int limit ) {

        // Create Chart
        PieChart chart =
                new PieChartBuilder().width(800).height(600).title("Pie Chart for Company").build();

        // Customize Chart
        chart.getStyler().setCircular(false);
        chart.getStyler().setLegendPosition(Styler.LegendPosition.OutsideS);
        chart.getStyler().setLegendLayout(Styler.LegendLayout.Horizontal);

        Dataset<Row> Company = companyCount.select("Company");
        List<String> CompanyList = new ArrayList<>();
        CompanyList   = Company.as(Encoders.STRING()).collectAsList();

        Dataset<Row> count = companyCount.select("count");
        List<String> CountList = new ArrayList<>();
        CountList   = count.as(Encoders.STRING()).collectAsList();

        for (int i=0; i < limit ; i++) {
            chart.addSeries(CompanyList.get(i), Integer.parseInt(CountList.get(i)));
        }
        return chart;
    }

}